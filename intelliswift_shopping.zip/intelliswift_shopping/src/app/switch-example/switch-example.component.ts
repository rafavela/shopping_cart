import { Component } from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-switch-example',
  templateUrl: './switch-example.component.html',
  styleUrls: ['./switch-example.component.css']
})
export class SwitchExampleComponent {
  productsArr:Products[];
  countryName:string;
  showDark:boolean;
  tableClasses:any;
  err:boolean;
  borderColor:string;
  constructor()
  {
    this.borderColor="green";
    this.err=false;
    this.showDark=false;
    this.tableClasses={
      "table-dark":this.showDark,
      "table-light":!this.showDark
    };

    
    this.countryName="Hong Kong";
    this.productsArr=[
      new Products(101,"Apple Macbook",220000,12,"./assets/appleMacbook.jpg","Apple mac book pro 13 inch grey color 1tb"),
      new Products(102,"Asus Laptop",135000,1,"./assets/asus.jpg","Asus laptop 500gb Intel Core I7"),
      new Products(103,"Dell Latitude",170000,5,"./assets/dellLatitude.jpg","Dell Latitude 2 in 1, Intel I9 Convertible Laptop"),
      new Products(104,"HP Laptop",140000,7,"./assets/hp.jpg","Hp Laptop, Active pen support, Intel Core I7 500gb"),
      new Products(105,"Lenovo Air",120000,9,"./assets/lenovo.jpg","Lenovo 2 in 1 Convertible Intel Core I9 8th gen"),
    ]
  }
  changeMode(mode:string) {
    //alert(mode);
    if(mode=="dark")
      {
        this.showDark=true;
      }  
      else
      {
        this.showDark=false;
      }
      this.tableClasses={
        "table-dark":this.showDark,
        "table-light":!this.showDark
      };
  
  }
  checkAgeEventHandler(enteredAge:string)
  {
    var age:number=parseInt(enteredAge);
    if(age <18)
      {
        this.err=true;
        
      }
      else
      {
        this.err=false;
        
      }
      this.borderColor=this.err?"red":"green";

  }
  
}
