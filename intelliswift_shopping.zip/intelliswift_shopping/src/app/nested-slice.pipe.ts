import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'nestedSlice'
})
export class NestedSlicePipe implements PipeTransform {

  transform(value:string[], ...args: number[]) {
   // value -- data on which the pipe has been applied
   // args --array which holds the various parameters
   var start=0,end=0;
    if(args[0])
      {
        start=args[0];
      }
    if(args[1])
      {
        end=args[1];
        var transformedArr=value.map(item=>item.slice(start,end));
      }
      else
      {
        var transformedArr=value.map(item=>item.slice(start));
      }
   
   
   return transformedArr;
  }

}
