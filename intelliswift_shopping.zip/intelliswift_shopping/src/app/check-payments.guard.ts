import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';


export const checkPaymentsGuard: CanActivateFn = (route, state) => {
  console.log("Route in Can activate guard",route);
  console.log("State in Can activate guard",state);
  // if user is logged in, allow the navigation to payments
  // if user is not logged in, navigate to login page
  var userName=prompt("Enter the name");
  if(userName =="sara")
      {
        return true;
      }
  else
  {
      // get the Router service
      var router=inject(Router);
      router.navigate(["login"]);
      return false;
  }
};
