import { DisplayArrayPipe } from './display-array.pipe';

describe('DisplayArrayPipe', () => {
  it('create an instance', () => {
    const pipe = new DisplayArrayPipe();
    expect(pipe).toBeTruthy();
  });
});
