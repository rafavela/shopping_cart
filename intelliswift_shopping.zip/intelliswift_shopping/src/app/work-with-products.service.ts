import { Injectable } from '@angular/core';
import { Products } from './products';

@Injectable({
  providedIn: 'root'
})
export class WorkWithProductsService {
productsArr:Products[];
  constructor() { 
    this.productsArr = [
      new Products(
        101,
        'Apple Macbook Air',
        120000,
        12,
        '../../assets/laptop1.jpeg',
        'Apple mac book Air 13 inch grey color 1tb'
      ),
      new Products(
        102,
        'Apple Mac book Pro',
        130000,
        13,
        '../../assets/laptop2.jpeg',
        '14-inch Liquid Retina XDR display'
      ),
      new Products(
        103,
        'Chromebook',
        140000,
        14,
        '../../assets/laptop3.jpeg',
        'ASUS 14" 2-in-1 Chromebook Plus Laptop'
      ),
      new Products(
        104,
        'DELL',
        150000,
        15,
        '../../assets/laptop4.jpeg',
        'Dell Technologies recommends Windows 11 Pro for business'
      ),
      new Products(
        105,
        'Lenovo',
        160000,
        16,
        '../../assets/laptop5.jpeg',
        'Lenovo IdeaPad FHD Laptop Intel'
      ),
      new Products(
        106,
        'Compaq presario',
        170000,
        17,
        '../../assets/laptop6.jpeg',
        'Compaq Presario CQ43-410LA Notebook PC'
      ),
      new Products(
        107,
        'thinkpad',
        180000,
        18,
        '../../assets/laptop7.jpeg',
        'Lenovo ThinkPad E16 Gen 1 21JT'
      ),
      new Products(
        108,
        'HP',
        190000,
        19,
        '../../assets/laptop8.jpeg',
        'HP ProBook 450 Generation 10 - 15.6'
      ),
      new Products(
        109,
        'Microsoft surface',
        200000,
        20,
        '../../assets/laptop9.jpeg',
        'Microsoft Surface Laptop 3'
      ),
      new Products(
        110,
        'LG',
        120000,
        21,
        '../../assets/laptop10.jpeg',
        'LG gram Pro 16” OLED 2in1'
      ),
    ];
  }

  getAllProducts()
  {
    return this.productsArr;
  }

  getProductDetail(productId:number)
  {
    return this.productsArr.find(item=>item.productId == productId);
  }

}
