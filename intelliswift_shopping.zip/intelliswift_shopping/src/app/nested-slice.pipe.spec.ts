import { NestedSlicePipe } from './nested-slice.pipe';

describe('NestedSlicePipe', () => {
  it('create an instance', () => {
    const pipe = new NestedSlicePipe();
    expect(pipe).toBeTruthy();
  });
});
