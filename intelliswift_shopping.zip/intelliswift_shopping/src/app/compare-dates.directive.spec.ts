import { CompareDatesDirective } from './compare-dates.directive';

describe('CompareDatesDirective', () => {
  it('should create an instance', () => {
    const directive = new CompareDatesDirective();
    expect(directive).toBeTruthy();
  });
});
