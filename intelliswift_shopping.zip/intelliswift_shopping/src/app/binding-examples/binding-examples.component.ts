import { Component } from '@angular/core';

@Component({
  selector: 'app-binding-examples',
  templateUrl: './binding-examples.component.html',
  styleUrls: ['./binding-examples.component.css']
})
export class BindingExamplesComponent {
firstName:string; // one way data binding in both the directions
lastName:string; // two way data binding
constructor()
{
  this.firstName="Sara";
  this.lastName="Gupta"
}
changeEventHandler(event:any)
{
  console.log("Change event triggered");// text box loses focus
  //this.firstName=event.target.value
}
inputEventHandler(event:any)
{
  console.log("Input event triggered");;// key press, key up, enter
  this.firstName=event.target.value
}
}
