import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BindingExamplesComponent } from './binding-examples.component';

describe('BindingExamplesComponent', () => {
  let component: BindingExamplesComponent;
  let fixture: ComponentFixture<BindingExamplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BindingExamplesComponent]
    });
    fixture = TestBed.createComponent(BindingExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
