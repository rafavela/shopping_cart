import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-wire-transfer',
  templateUrl: './payment-by-wire-transfer.component.html',
  styleUrls: ['./payment-by-wire-transfer.component.css']
})
export class PaymentByWireTransferComponent {

}
