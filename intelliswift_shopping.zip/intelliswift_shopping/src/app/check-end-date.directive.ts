import { Directive, Input } from '@angular/core';
import {
  AbstractControl,
  NG_VALIDATORS,
  ValidationErrors,
  Validator,
} from '@angular/forms';
import { checkEndDateValue } from 'src/Validators/checkEndDate';

@Directive({
  selector: '[appCheckEndDate]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: CheckEndDateDirective,
      multi: true,
    },
  ],
})
export class CheckEndDateDirective implements Validator {
  @Input() appCheckEndDate: Date;
  constructor() {
    this.appCheckEndDate = new Date();
  }
  validate(control: AbstractControl<any, any>): ValidationErrors | null {
    console.log('In validate ' + this.appCheckEndDate.getFullYear());
    return checkEndDateValue(this.appCheckEndDate)(control);
  }
}
