import { Component,EventEmitter,Input, Output, OnInit, booleanAttribute, numberAttribute } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  private myCompanyName:string;

  @Input({transform:numberAttribute})salaryCheck:number;
  @Input({transform:booleanAttribute}) showSalary:boolean;


@Input({required:true}) myEmployee:Object ;
 @Input() 
get companyName()
{
  return this.myCompanyName;
}
set companyName(value:string)
{
   this.myCompanyName=value.toUpperCase();
} 

@Input(
  {   required:true,
      transform: 
      (value:any[])=>{
                 return value.filter((item) => (item?.["projectId"] == "P101")
                  )
                
                }
}
) empArr:Object[];

@Input({alias:"counter"}) ctr:number;
@Input() bonusPercentage:number;
@Input() projectType:string;

@Output() passCtr:EventEmitter<number>;

  constructor()
  {
    this.projectType=""
    this.bonusPercentage=0;
    this.ctr=0;
    this.myEmployee=new Object();
    this.myCompanyName="Sudaksha";
    this.empArr=[];
    console.log("Employee details in constructor",this.myEmployee);// displaying an empty object
    this.salaryCheck=0;
    this.showSalary=false;
    this.passCtr=new EventEmitter<number>();
  }
  ngOnInit(): void {
    console.log("Employee details in ngOnInit",this.myEmployee);// will display the data received from the parent
  }

  incrementCounterEventHandler()
  {
    this.ctr++;
    this.passCtr.emit(this.ctr);
  }

}
