import { Component } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent {
  counter:number;
  bonusPercentage:number;
  emp:Object;
  companyName:string;
  empArr:any[];
  salaryCheck:string;
  constructor()
  {
    this.bonusPercentage=0.25;
    this.counter=0;
    this.emp={
      empId:100,
      empName:"sara",
      salary:45678
    }
    this.companyName="intelliswift";
    this.empArr=[{empId:101,empName:"Sara",projectId:"P101"},
    {empId:102,empName:"Keshav",projectId:"P101"},
    {empId:103,empName:"Saurabh",projectId:"P102"},
    {empId:104,empName:"Giri",projectId:"P102"},
    {empId:105,empName:"Saraansh",projectId:"P103"},
    {empId:106,empName:"Piyush",projectId:"P104"},
    {empId:107,empName:"Neha",projectId:"P104"},
    {empId:108,empName:"Priyam",projectId:"P105"},
    {empId:109,empName:"Pranav",projectId:"P105"},
    {empId:110,empName:"Puja",projectId:"P104"}];

    this.salaryCheck="10000";

  }
  passCtrEventHandler(data:number)
  {
    alert("data received from the child" + data);
    this.counter=data;
  }

}
