import {
  Component,
  DoCheck,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
} from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-add-to-cart',
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css'],
})
export class AddToCartComponent implements OnChanges, DoCheck, OnDestroy {
  @Input() myCompanyName: string; // the data for this property will be received from the parent
  @Input() selProduct: Products | null;
  @Output() cancelProduct: EventEmitter<void>;
  @Output() confirmProduct: EventEmitter<any>;
  @Output() sendCartObjFromPlToHome: EventEmitter<any>;
  colors: string[] = ['red', 'green'];
  myColors: string[];
  quantitySelected: number;
  constructor() {
    this.sendCartObjFromPlToHome = new EventEmitter<any>();
    // alert('Constructor of ADDToCart Component called');
    this.quantitySelected = 1;
    this.myColors = ['red', 'green'];
    this.myCompanyName = '';
    this.selProduct = null;
    console.log('Selected product', this.selProduct); //expected output : HP Laptop; actual output:null
    this.cancelProduct = new EventEmitter<void>();
    this.confirmProduct = new EventEmitter<any>();
  }
  ngOnDestroy(): void {
    // alert('ngOnDestroy of AddToCart called ');
  }
  ngDoCheck(): void {
    // console.log('ngDoCheck of AddToCart component called');
    // when all is this lifecycle method invoked --
    // -- during the mounting phase -- YES
    // when in mounting phase -- after constructor, ngOnChanges, ngOnInit
    //-- during the updation phase
    // -- any changes to the state or @Input
    // invoked once or invoked many times -- invoked many times
  }
  ngOnChanges(changes: SimpleChanges): void {
    // Will updations to quantitySelected trigger the ngOnChanges method -- NO
    // Triggered when the data flowing from the parent(@Input) changes(initialisation is also a change)
    // check if there are values in @Input selProduct
    // check if it is not the first Change:
    // If not the first change; check if the productId is not different -- Not neeeded because ngOnChanges gets invoked only if the @Input changes
    // If yes for all the above   -- reinitialise quantitySelected to 1
    if (changes?.['selProduct']) {
      //check if there are values in @Input selProduct
      if (!changes?.['selProduct']?.firstChange) {
        // check if it is not the first Change:
        this.quantitySelected = 1;
      }
    }

    console.log('Changes in AddToCart Component', changes);
  }
  changeQuantityEventHandler(op: string) {
    if (op == 'inc') {
      if (
        this.selProduct &&
        this.quantitySelected < this.selProduct?.quantity
      ) {
        this.quantitySelected++;
      }
    } else {
      if (this.quantitySelected > 1) {
        this.quantitySelected--;
      }
    }
  }
  cancelEventHandler() {
    // trigger the event and have no data embedded as part of event
    this.cancelProduct.emit();
  }

  confirmEventHandler() {
    var cartObj: any = {
      ...this.selProduct,
      quantitySelected: this.quantitySelected,
    };
    this.confirmProduct.emit(cartObj);
    this.sendCartObjFromPlToHome;
  }
}
