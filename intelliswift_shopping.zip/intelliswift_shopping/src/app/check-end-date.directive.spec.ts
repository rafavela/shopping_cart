import { CheckEndDateDirective } from './check-end-date.directive';

describe('CheckEndDateDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckEndDateDirective();
    expect(directive).toBeTruthy();
  });
});
