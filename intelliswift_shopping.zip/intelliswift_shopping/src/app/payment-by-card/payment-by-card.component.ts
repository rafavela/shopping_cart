import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-card',
  templateUrl: './payment-by-card.component.html',
  styleUrls: ['./payment-by-card.component.css']
})
export class PaymentByCardComponent {

}
