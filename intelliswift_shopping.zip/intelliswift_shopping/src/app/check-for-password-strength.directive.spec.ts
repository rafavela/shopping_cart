import { CheckForPasswordStrengthDirective } from './check-for-password-strength.directive';

describe('CheckForPasswordStrengthDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckForPasswordStrengthDirective();
    expect(directive).toBeTruthy();
  });
});
