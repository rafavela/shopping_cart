import { Component } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent {
  dbStartDate: Date;
  dbEndDate: Date;
  serverErrors: string;
  constructor(private authService: AuthService, private router: Router) {
    var today = new Date();
    this.dbStartDate = new Date(today.getFullYear() - 3, 0, 1);
    this.dbEndDate = new Date(today.getFullYear() + 3, 0, 1);
    this.serverErrors = '';
  }
  signInEventHandler(registerForm: any) {
    console.log('Form values', registerForm.value);
    var userObject = registerForm.value;
    var result: any = this.authService.registerUser(userObject);
    if (result['status'] == true) {
      alert('Registration successful');
      this.router.navigate(['login']);
    } else {
      alert('User email Id already exists');
      this.serverErrors = 'EAE';
    }
  }
  displayStartDate(ev: any) {
    console.log('date selected', ev.target.value);
  }
}
