import { Component } from '@angular/core';
import { Observable, Observer, filter, from, interval, map, of, take, tap } from 'rxjs';

@Component({
  selector: 'app-rxjs-examples',
  templateUrl: './rxjs-examples.component.html',
  styleUrls: ['./rxjs-examples.component.css']
})
export class RxjsExamplesComponent {
  obs1$:Observable<number>;
  obs2$:Observable<number>;
  obs3$:Observable<string>;
  obs4$:Observable<string>;
  obs5$:Observable<Object>;
  obs6$:Observable<any>;
  employeeArr:Array<Object>;
  obs7$:Observable<Array<Object>>;
  obs8$:Observable<number>;
    constructor()
  {
   this.obs1$=of(1,2,3);
   console.log("Before subscribing to the observable")
   this.obs1$.subscribe({
    next:(data)=>{console.log(data);},
    error:(err)=>{console.log("Error",err)},
    complete:()=>{console.log("Stream complete")}
   })
   this.obs2$=of(1,2,3);
   this.obs3$=of("red","blue","green","violet").pipe(
    map(item=> item.toUpperCase()),
    filter(item =>item.includes("R"))
   )

   this.obs3$.subscribe({
    next(data){
      console.log(data)
    },
    error(err){console.log(err)},
    complete(){ console.log("Stream complete")}
   })
   this.obs4$=new Observable(this.createMyObservableFunction);

   this.obs4$.subscribe({
    next:console.log,
    complete:()=>console.log("Complete")
   })

   this.employeeArr=[];
   this.obs5$=new Observable(this.createMyEmpObservable);
   this.obs5$.subscribe({
    next:(data)=>{this.employeeArr.push(data)},
    complete:()=>console.log("Complete")
   })

   this.obs6$=new Observable(this.createMyEmpObservable);
   //this.obs6$=from([1,2,3,4,5,6])

   this.obs7$=new Observable(this.createMyEmpArrObservable);
console.log("Example of take, interval and tap");
this.obs8$=  interval(2000)
  .pipe(
    take(5),
    tap(item => console.log(item))
  );
  //this.obs8$.subscribe(value => console.log(`Observer 1 received the value : ${value}`));
  //this.obs8$.subscribe(value => console.log(`Observer 2 received the value : ${value}`));


  }
   squaresGenerationEventHandler(num1:any)
   {
      var arr=[];
      for(let i=parseInt(num1);i<parseInt(num1)+10;i++ )
        arr.push(i);
      this.obs2$=from(arr);
      var observer={
        next:(data:any)=>{console.log(data);},
        error:(err:any)=>{console.log("Error",err)},
        complete:()=>{console.log("Stream complete")}
      }
      var subscriber1=this.obs2$.subscribe(observer)

      // Can there be multiple observers for the same Observable
      var observer2={
        next:(data:any)=>{console.log(data*data);},
        error:(err:any)=>{console.log("Error",err)},
        complete:()=>{console.log("Stream complete")}
      }
      var subscriber2=this.obs2$.subscribe(observer2);

      subscriber1.unsubscribe();


   }

   createMyObservableFunction(observer:Observer<string>)
   {
      observer.next("one");
      observer.next("two");
      observer.next("three");
      observer.next("four");
      setTimeout(()=>{
        observer.next("five")
        observer.complete();
      },5000);
      return ()=>{
        // function will be invoked when the unsubscription happens
        console.log("Unsubscribed from the observable")
      }


   }
   createMyEmpObservable(observer:Observer<Object>)
   {
    var empArr=[{empId:101,empName:"Asha",salary:1001,deptId:"D1"},
    {empId:102,empName:"Gaurav",salary:2000,deptId:"D1"},
    {empId:103,empName:"Karan",salary:2000,deptId:"D2"},
    {empId:104,empName:"Kishan",salary:3000,deptId:"D1"},
    {empId:105,empName:"Keshav",salary:3500,deptId:"D2"},
    {empId:106,empName:"Pran",salary:4000,deptId:"D3"},
    {empId:107,empName:"Saurav",salary:3800,deptId:"D3"}]
    
    for(let i=0;i<empArr.length;i++)
      {
        observer.next(empArr[i]);
      }
    
        observer.complete();
      return ()=>{
        // function will be invoked when the unsubscription happens
        console.log("Unsubscribed from the observable")
      }


   }

   createMyEmpArrObservable(observer:Observer<Array<Object>>)
   {
    var empArr=[{empId:101,empName:"Asha",salary:1001,deptId:"D1"},
    {empId:102,empName:"Gaurav",salary:2000,deptId:"D1"},
    {empId:103,empName:"Karan",salary:2000,deptId:"D2"},
    {empId:104,empName:"Kishan",salary:3000,deptId:"D1"},
    {empId:105,empName:"Keshav",salary:3500,deptId:"D2"},
    {empId:106,empName:"Pran",salary:4000,deptId:"D3"},
    {empId:107,empName:"Saurav",salary:3800,deptId:"D3"}]
    
        observer.next(empArr);
      
    
        observer.complete();
      return ()=>{
        // function will be invoked when the unsubscription happens
        console.log("Unsubscribed from the observable")
      }


   }


  }

