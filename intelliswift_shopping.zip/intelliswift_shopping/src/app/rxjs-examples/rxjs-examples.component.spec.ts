import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RxjsExamplesComponent } from './rxjs-examples.component';

describe('RxjsExamplesComponent', () => {
  let component: RxjsExamplesComponent;
  let fixture: ComponentFixture<RxjsExamplesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RxjsExamplesComponent]
    });
    fixture = TestBed.createComponent(RxjsExamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
