import { Component } from '@angular/core';

@Component({
  selector: 'app-custom-directive-examples',
  templateUrl: './custom-directive-examples.component.html',
  styleUrls: ['./custom-directive-examples.component.css']
})
export class CustomDirectiveExamplesComponent {

}
