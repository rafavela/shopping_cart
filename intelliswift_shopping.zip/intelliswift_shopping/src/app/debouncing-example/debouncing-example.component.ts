import { Component, OnInit } from '@angular/core';
import {
  Subject,
  debounce,
  debounceTime,
  distinctUntilChanged,
  switchMap,
} from 'rxjs';
import { TalkWithServerService } from '../talk-with-server.service';

@Component({
  selector: 'app-debouncing-example',
  templateUrl: './debouncing-example.component.html',
  styleUrls: ['./debouncing-example.component.css'],
})
export class DebouncingExampleComponent {
  // private searchText$:Subject<string>
  // constructor(private talkWithServer:TalkWithServerService) {
  //   this.searchText$= new Subject<string>()
  // }
  // ngOnInit(): void {
  //   this.searchText$.pipe(
  //     debounceTime(500),
  //     distinctUntilChanged(),
  //     switchMap(searchText)
  //   )
  // }
  // keyUpHandlerEvent(ev: any){
  //   console.log("value entered", ev.target.value)
  //   this.searchText$.next(ev.target.value);
  // }
}
