import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-apple-pay',
  templateUrl: './payment-by-apple-pay.component.html',
  styleUrls: ['./payment-by-apple-pay.component.css']
})
export class PaymentByApplePayComponent {

}
