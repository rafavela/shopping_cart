const { map } = require("ember-cli/lib/ext/promise");

var obj1={empId:101,empName:"sara"};

var obj2=obj1;// creating a reference
obj2.empName="tara";
console.log(obj1);//{empId:101,empName:"tara"};
console.log(obj2);//{empId:101,empName:"tara"};

// Copy of an object in ES5
var obj1={empId:101,empName:"sara"};
var obj3=Object.assign(obj3,obj1);
obj3.empName="tara";
console.log(obj1);//sara
console.log(obj3);//tara

// Copy of an object in ES6
var obj1={empId:101,empName:"sara"};
var obj4={...obj1};
obj4.empName="tara";
console.log(obj1);//sara
console.log(obj4);//tara

var obj1={empId:101,empName:"sara"};
var obj5={...obj1,salary:10000};
var obj6={...obj1,salary:10000,empId:567};
var obj7={empId:777,...obj1,salary:10000};
console.log(obj1);//{empId:101,empName:"sara"};
console.log(obj5);//{empId:101,empName:"sara",salary:10000};
console.log(obj6);//{empName:"sara",salary:10000,empId:567};
console.log(obj7);//{empId:101,empName:"sara",salary:10000};

var arr1=[10,20,30,40,50];

var sqArr=arr1.map(item => item*item);
console.log(sqArr);//[100,400,900,1600,2500]

var sqArr1=arr1.map(item => {
    if(item>30)
        return item*item;
});
console.log(sqArr1);//[ud,ud,ud,1600,2500],
/*map
    -- 1 param -- predicate function
    -- for each element the predicate function will be executed 
    -- size of resultant array = size of target array
*/ 

//filter and find
// filter -- get all the element(s) which satisfies the predicate function
var arr2=[10,20,30,10,50,20,60];
var resArr=arr2.filter((item)=> item >30);//[50,60]
//find -- get the first element which satisfies the predicate function
var res=arr2.find((item)=> item >30);//50;

var resArr2=arr2.filter((item)=> item >300);//[]
var res2=arr2.find((item)=> item >300);//ud

// filterIndex and findIndex
//findIndex -- position of first element which satisfies the predicate function
var arr2=[10,20,30,10,50,20,60];
var pos=arr2.findIndex((item)=> item >30);//4;
var pos1=arr2.findIndex((item)=> item >300);//-1;

//filterIndex -- no method with this name exists
var posArr=arr2.filterIndex((item)=> item >30);// error
var posArr1=arr2.filterIndex((item)=> item >300);//error 


var empArr=[{empId:101,empName:"Asha",salary:1001,deptId:"D1"},
{empId:102,empName:"Gaurav",salary:2000,deptId:"D1"},
{empId:103,empName:"Karan",salary:2000,deptId:"D2"},
{empId:104,empName:"Kishan",salary:3000,deptId:"D1"},
{empId:105,empName:"Keshav",salary:3500,deptId:"D2"},
{empId:106,empName:"Pran",salary:4000,deptId:"D3"},
{empId:107,empName:"Saurav",salary:3800,deptId:"D3"}]

var person=empArr.find(item => item.salary==4000);//{empId:106,empName:"Pran",salary:4000,deptId:"D3"}
person.empName="sara";
console.log(person);//{empId:106,empName:"sara",salary:4000,deptId:"D3"}
console.log(empArr[5]);//{empId:106,empName:"Pran",salary:4000,deptId:"D3"}
// find -- return a reference










