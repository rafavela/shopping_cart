import { Component } from '@angular/core';
import { Products } from '../products';
import { WorkWithProductsService } from '../work-with-products.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent {
  showCart: boolean;
  //cartObj:any;
  cartArr: any[];
  productsArr: Array<Products>;
  productSum: number;
  constructor(private workWithProduct: WorkWithProductsService) {
    this.productsArr = workWithProduct.getAllProducts();
    this.showCart = true;
    //this.cartObj=null;
    this.cartArr = [];
    this.productSum = 0;
  }
  toggleDisplay() {
    this.showCart = !this.showCart;
  }
  sendCartObjFromPlToHomeHandler(cartObj: any) {
    //this.cartObj=cartObj;
    // check if the product already exists in the cart
    // alert('sendCartObjFromPlToHomeHandler ' + cartObj.productId);
    var pos = this.cartArr.findIndex(
      (product) => product.productId == cartObj.productId
    );
    if (pos >= 0) {
      // product already exists in the cartArr;
      // sum of quantitySelected
      this.cartArr[pos].quantitySelected += cartObj.quantitySelected;
    } else {
      // product does not exists; pos=-1
      this.cartArr.push(cartObj);
    }
    this.sum();
  }

  sum() {
    let sum = 0;
    this.cartArr.forEach((product) => {
      sum += product.quantitySelected;
    });
    this.productSum = sum;
  }
}
