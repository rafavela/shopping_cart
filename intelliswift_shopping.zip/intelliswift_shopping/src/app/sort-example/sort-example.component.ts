import { Component, OnChanges, SimpleChanges } from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-sort-example',
  templateUrl: './sort-example.component.html',
  styleUrls: ['./sort-example.component.css'],
})
export class SortExampleComponent {
  productsArr: Products[];
  sortField: string;
  sortOrder: string;
  arrowValue: string;
  searchTerm: string;
  showEditProduct: boolean;
  productToBeEdited: Products | null;
  columnDirection: string;
  headersArr: string[];
  constructor() {
    this.searchTerm = '';
    this.sortField = 'productId';
    this.sortOrder = 'asc';
    this.arrowValue = 'DescriptionAscending';
    this.showEditProduct = false;
    this.productToBeEdited = null;
    this.columnDirection = '';
    this.headersArr = ['productId', 'name', 'price', 'description', 'quantity'];
    this.productsArr = [
      new Products(
        101,
        'Apple Macbook',
        220000,
        12,
        './assets/appleMacbook.jpg',
        'Apple mac book pro 13 inch grey color 1tb'
      ),
      new Products(
        102,
        'Asus Laptop',
        135000,
        1,
        './assets/asus.jpg',
        'Asus laptop 500gb Intel Core I7'
      ),
      new Products(
        103,
        'Dell Latitude',
        170000,
        5,
        './assets/dellLatitude.jpg',
        'Dell Latitude 2 in 1, Intel I9 Convertible Laptop'
      ),
      new Products(
        104,
        'HP Laptop',
        140000,
        7,
        './assets/hp.jpg',
        'Hp Laptop, Active pen support, Intel Core I7 500gb'
      ),
      new Products(
        105,
        'Lenovo Air',
        120000,
        9,
        './assets/lenovo.jpg',
        'Lenovo 2 in 1 Convertible Intel Core I9 8th gen'
      ),
    ];
  }
  ngOnChanges(changes: SimpleChanges): void {
    this.columnDirection = 'productNameUp';
  }
  sortEventHandler(columnDirection: string) {
    console.log('column ' + columnDirection);
    switch (columnDirection) {
      case 'productIdUp':
        this.sort('productId', 'asc');
        this.columnDirection = 'productIdUp';
        break;
      case 'nameUp':
        this.sort('productName', 'asc');
        this.columnDirection = 'nameUp';
        break;
      case 'priceUp':
        this.sort('price', 'asc');
        this.columnDirection = 'priceUp';
        break;
      case 'descriptionUp':
        this.sort('description', 'asc');
        this.columnDirection = 'descriptionUp';
        break;
      case 'quantityUp':
        this.sort('quantity', 'asc');
        this.columnDirection = 'quantityUp';
        break;
      case 'productIdDown':
        this.sort('productId', 'desc');
        this.columnDirection = 'productIdDown';
        break;
      case 'nameDown':
        this.sort('productName', 'desc');
        this.columnDirection = 'nameDown';
        break;
      case 'priceDown':
        this.sort('price', 'desc');
        this.columnDirection = 'priceDown';
        break;
      case 'descriptionDown':
        this.sort('description', 'desc');
        this.columnDirection = 'descriptionDown';
        break;
      case 'quantityDown':
        this.sort('quantity', 'desc');
        this.columnDirection = 'quantityDown';
        break;
      default:
        break;
    }
  }

  private toggleDirection(header: string, up: string, down: string) {
    let direction = this.setDirection(header, up, down);
    this.sort(header, direction);
  }

  private setDirection(header: string, up: string, down: string): string {
    if (this.arrowValue === up) {
      this.arrowValue = down;
      return 'desc';
    } else {
      this.arrowValue = up;
      return 'asc';
    }
  }

  private sort(header: string, direction: string) {
    this.sortField = header;
    this.sortOrder = direction;
  }

  searchEventHandler(searchTextBox: any) {
    this.searchTerm = searchTextBox.value;
  }

  displayEditProduct(productEdited: Products) {
    this.showEditProduct = true;
    this.productToBeEdited = productEdited;
  }
}
