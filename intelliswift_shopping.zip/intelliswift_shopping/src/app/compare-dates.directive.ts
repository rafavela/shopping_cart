import { Directive, Input } from '@angular/core';
import {
  AbstractControl,
  FormGroup,
  NG_VALIDATORS,
  ValidationErrors,
  Validator,
} from '@angular/forms';
import { validateDates } from 'src/Validators/compareDates';

@Directive({
  selector: '[appCompareDates]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: CompareDatesDirective,
      multi: true,
    },
  ],
})
export class CompareDatesDirective implements Validator {
  @Input() appCompareDates: string[];

  constructor() {
    this.appCompareDates = [];
  }
  validate(formGroup: FormGroup): ValidationErrors | null {
    console.log('in validate directive');
    return validateDates(
      this.appCompareDates[0],
      this.appCompareDates[1]
    )(formGroup);
  }
}
