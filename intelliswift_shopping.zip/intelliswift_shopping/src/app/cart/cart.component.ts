import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
@Input() cartArr:any[];
today:Date;
constructor(private router:Router)
{
  this.cartArr=[];
  this.today=new Date();
}
paymentsEventHandler()
{
  this.router.navigate(["payments"]); 
}
}
