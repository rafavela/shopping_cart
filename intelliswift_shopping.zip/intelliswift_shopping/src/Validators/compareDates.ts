import { FormGroup } from '@angular/forms';
export function validateDates(controlName1: string, controlName2: string) {
  return function (formGroup: FormGroup) {
    var control1 = formGroup.controls[controlName1];
    var control2 = formGroup.controls[controlName2];

    if (!control1 || !control2) {
      //control2.setErrors(null);
      return null;
    }

    if (control1.value < control2.value) {
      console.log('dates validator if');
      if (control2.errors) {
        return control2.errors;
      }
      control2.setErrors(null);
      return null;
    } else {
      console.log('dates validator else');
      control2.setErrors({ isDateValid: true });
      return { isDateValid: true };
    }
  };
}
