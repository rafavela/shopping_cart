import { AbstractControl } from '@angular/forms';

export function checkEndDateValue(dbEndDate: Date) {
  return function (control: AbstractControl) {
    console.log('In checkEndDateValue ' + dbEndDate);
    if (!control.value) {
      return null;
    }

    var value = control.value; // string format of the selected date
    console.log(value);
    var valueInDateObj = new Date(value);
    var year = valueInDateObj.getFullYear();
    if (year < dbEndDate.getFullYear()) {
      console.log('if');
      return null;
    } else {
      console.log('else');
      return { endDateValue: true };
    }
  };
}
