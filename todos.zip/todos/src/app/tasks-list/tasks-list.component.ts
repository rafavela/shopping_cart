import { Component, Input } from '@angular/core';
import { Store } from '@ngrx/store';
import { TasksActions } from '../store/task.action';
import { Task } from '../model/task';

@Component({
  selector: 'app-tasks-list',
  templateUrl: './tasks-list.component.html',
  styleUrls: ['./tasks-list.component.css'],
})
export class TasksListComponent {
  @Input() todos: Array<Task>;
  constructor(private store: Store) {
    this.todos = [];
  }
  completedEventHandler(task: Task) {
    // added to the completed Tasks List;
    // dispatch an action
    this.store.dispatch(TasksActions.markTaskAsCompleted({ task }));
  }
  deleteEventHandler(task: Task) {
    // added to the completed Tasks List;
    // dispatch an action
    this.store.dispatch(TasksActions.deleteTask({ taskId: task.id }));
  }
}
