import { createReducer, on } from '@ngrx/store';
// import { Tasks } from '../tasks';
import { TasksActions } from './task.action';
import { Task } from '../model/task';

export const initialState: Array<Task> = [];

export const completedTasksReducer = createReducer(
  initialState,
  on(TasksActions.markTaskAsCompleted, (state, { task }) => {
    var newState = [...state, task];
    return newState;
  }),
  on(TasksActions.reopenTask, (state, { task }) => {
    var newState = [...state];
    var pos = newState.findIndex((item) => item.id == task.id);
    if (pos >= 0) {
      newState.splice(pos, 1);
    }
    return newState;
  })
);
