import { createActionGroup, props } from '@ngrx/store';
import { Task } from '../model/task';

// import { Tasks } from '../tasks';

export const TasksApiActions = createActionGroup({
  source: 'Tasks API',
  events: {
    'Load Tasks': props<{ tasksArr: Array<Task> }>(),
  },
});

// create another action group with 3 events-- add, remove ,mark as completed

export const TasksActions = createActionGroup({
  source: 'Tasks',
  events: {
    'Add Task': props<{ task: Task }>(),
    'Delete Task': props<{ taskId: number }>(),
    'Mark Task As Completed': props<{ task: Task }>(),
    'Reopen Task': props<{ task: Task }>(),
  },
});
