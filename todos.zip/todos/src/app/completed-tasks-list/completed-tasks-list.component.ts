import { Component, Input } from '@angular/core';
import { Task } from '../model/task';
import { Store } from '@ngrx/store';
import { TasksActions } from '../store/task.action';

@Component({
  selector: 'app-completed-tasks-list',
  templateUrl: './completed-tasks-list.component.html',
  styleUrls: ['./completed-tasks-list.component.css'],
})
export class CompletedTasksListComponent {
  @Input() completedTasks: Array<Task>;
  constructor(private store: Store) {
    this.completedTasks = [];
  }
  reopenTaskHandler(task: Task) {
    this.store.dispatch(TasksActions.reopenTask({ task }));
  }
}
